%The commands here provide a typical fitting procedure; 

load filename.txt  
% load data in filename.txt
%filename.txt includes two columns, the postion and the spectral intensity. 

fitfun=fittype('conv_fun(a,6.2,4.7,l,x)') 
% definition of fitting function. 
%6.2 and 4.7 are the FWHM of the field intensity profile and resolution profile, respectively
%6.2 and 4.7 should be revised according to practical system. 

fitresult=fit(filename(:,1), filename(:,2),fitfun,'startpoin',[2 4 ]) 
% Fit the function to obtain the transport distance l.