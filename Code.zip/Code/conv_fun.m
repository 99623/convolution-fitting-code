function reaction_profile = conv_fun(a,c1,c2,l,x)
%this code calculates the distribution of hot carriers
%a is an amplitude constant
%c1 and c2 are FWHM of plasmonic intensity and resolution profile,respectively
%l is the transport distance of hot carriers
%x is position
%y is population of hot carriers at postion x
interval=0.1; %the interval of position used to convolution.
xx=(min(x)):interval:(max(x));
plasmonic_field=exp(-xx.^2/(c1/2/sqrt(log(2))).^2);
resolution_profile=exp(-xx.^2/(c2/2/sqrt(log(2))).^2);
exponential_attenuation_of_Hotelectron=exp(-abs(xx)/l);
reaction_profile_simulation=a*conv(conv(plasmonic_field,resolution_profile)*interval,exponential_attenuation_of_Hotelectron)*interval;
position_simulation=3*min(xx):0.1:3*max(xx);
reaction_profile=interp1(position_simulation,reaction_profile_simulation,x);
end



