function reacion_profile = conv_fun(a,c1,c2,l,x)
%this code calculates the distribution of hot carriers
%a is an amplitude constant
%c1 and c2 are FWHM of plasmonic intensity and resolution profile,respectively
%l is the spread distance of hot carries
%x is position
%y is population of hot carries at postion x
%see more details in our manuscript submit to nature communication, 
%entitle "Probing nanoscale spatial distribution of plasmonically excited hot carriers"
%the file is revised at 2020-7-22
%If there have any problem, contact xxxx@xxx for helps  
interval=0.1; %the interval of position used to convolution.
xx=(min(x)):interval:(max(x));
plasmonic_field=exp(-xx.^2/(c1/2/sqrt(log(2))).^2);
resolution_profile=exp(-xx.^2/(c2/2/sqrt(log(2))).^2);
exponential_attenuation_of_Hotelection=exp(-abs(xx)/l);
reacion_profile_simulation=a*conv(conv(plasmonic_field,resolution_profile)*interval,exponential_attenuation_of_Hotelection)*interval;
position_simulation=3*min(xx):0.1:3*max(xx);
reaction_profile=interp1(position_simulation,reacion_profile_simulation,x);
end



